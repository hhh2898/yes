package com.ruggedsurvival.paper.config;

import org.bukkit.configuration.file.FileConfiguration;

/**
 * Typed, clamped snapshot of config.yml. Every default matches the design spec.
 * Call {@link #load} again after the file changes to refresh.
 */
public final class RuggedConfig {
    public boolean showJoinMessage;

    // features
    public boolean enableThirst, enableTreeRestrictions, enableAging, enableLongerDays, enableBleeding, enableArmorAgeGates;

    // longer days
    public int dayLengthMinutes;

    // thirst
    public int thirstCapacity;
    public double thirstDrainMultiplier;
    public int thirstIdleTicksPerPoint;
    public double thirstSprintMultiplier;
    public double thirstJumpCost;
    public double unsafeWaterDrainMultiplier;
    public int unsafeWaterDurationSeconds;
    public boolean unsafeWaterNausea;
    public int filterMediaYield;
    public double filteredWaterRestore;
    public double drinkFromSourceAmount;
    public boolean resetThirstOnDeath;

    // tree gathering
    public double bareHandLogDamage;
    public int bareHandLogCooldownTicks;
    public double looseRockSpawnRate;
    public int crudeHandaxeDurability;
    public double looseRockFallbackChance;
    public double looseStickFallbackChance;

    // aging
    public int startingHearts, maxHearts, startingAge, daysPerAge, ageCap;
    public boolean countOfflineTime, resetAgeOnDeath;

    // armor unlock ages
    public int armorLeather, armorChainmail, armorGold, armorIron, armorDiamond, armorNetherite;

    // bleeding
    public double bleedChance, bleedMinDamage, bleedDamage;
    public int bleedDurationSeconds, bleedIntervalSeconds;
    public boolean bleedCanBeLethal, bleedFromEnvironment;

    public static RuggedConfig load(FileConfiguration c) {
        RuggedConfig r = new RuggedConfig();
        r.showJoinMessage = c.getBoolean("show-join-message", true);

        r.enableThirst = c.getBoolean("features.thirst", true);
        r.enableTreeRestrictions = c.getBoolean("features.tree-restrictions", true);
        r.enableAging = c.getBoolean("features.aging", true);
        r.enableLongerDays = c.getBoolean("features.longer-days", true);
        r.enableBleeding = c.getBoolean("features.bleeding", true);
        r.enableArmorAgeGates = c.getBoolean("features.armor-age-gates", true);

        r.dayLengthMinutes = clamp(c.getInt("longer-days.day-length-minutes", 30), 20, 60);

        r.thirstCapacity = clamp(c.getInt("thirst.capacity", 10), 1, 40);
        r.thirstDrainMultiplier = Math.max(0.0, c.getDouble("thirst.drain-multiplier", 1.0));
        r.thirstIdleTicksPerPoint = clamp(c.getInt("thirst.idle-ticks-per-point", 2400), 20, 1_000_000);
        r.thirstSprintMultiplier = Math.max(1.0, c.getDouble("thirst.sprint-multiplier", 3.0));
        r.thirstJumpCost = Math.max(0.0, c.getDouble("thirst.jump-cost", 0.02));
        r.unsafeWaterDrainMultiplier = Math.max(1.0, c.getDouble("thirst.unsafe-water-drain-multiplier", 2.0));
        r.unsafeWaterDurationSeconds = clamp(c.getInt("thirst.unsafe-water-duration-seconds", 30), 1, 3600);
        r.unsafeWaterNausea = c.getBoolean("thirst.unsafe-water-nausea", true);
        r.filterMediaYield = clamp(c.getInt("thirst.filter-media-yield", 8), 1, 256);
        r.filteredWaterRestore = Math.max(0.0, c.getDouble("thirst.filtered-water-restore", 4.0));
        r.drinkFromSourceAmount = Math.max(0.0, c.getDouble("thirst.drink-from-source-amount", 1.0));
        r.resetThirstOnDeath = c.getBoolean("thirst.reset-on-death", true);

        r.bareHandLogDamage = Math.max(0.0, c.getDouble("tree-gathering.bare-hand-log-damage", 1.0));
        r.bareHandLogCooldownTicks = clamp(c.getInt("tree-gathering.bare-hand-log-cooldown-ticks", 20), 0, 1200);
        r.looseRockSpawnRate = Math.max(0.0, c.getDouble("tree-gathering.loose-rock-spawn-rate", 1.0));
        r.crudeHandaxeDurability = clamp(c.getInt("tree-gathering.crude-handaxe-durability", 16), 1, 1000);
        r.looseRockFallbackChance = clamp01(c.getDouble("tree-gathering.loose-rock-fallback-chance", 0.10));
        r.looseStickFallbackChance = clamp01(c.getDouble("tree-gathering.loose-stick-fallback-chance", 0.08));

        r.startingHearts = clamp(c.getInt("aging.starting-hearts", 4), 1, 100);
        r.maxHearts = clamp(c.getInt("aging.max-hearts", 15), r.startingHearts, 100);
        r.startingAge = clamp(c.getInt("aging.starting-age", 1), 1, 1000);
        r.daysPerAge = clamp(c.getInt("aging.days-per-age", 10), 1, 1000);
        r.ageCap = c.getInt("aging.age-cap", -1);
        r.countOfflineTime = c.getBoolean("aging.count-offline-time", false);
        r.resetAgeOnDeath = c.getBoolean("aging.reset-age-on-death", true);

        r.armorLeather = clamp(c.getInt("armor.leather", 1), 1, 1000);
        r.armorChainmail = clamp(c.getInt("armor.chainmail", 7), 1, 1000);
        r.armorGold = clamp(c.getInt("armor.gold", 11), 1, 1000);
        r.armorIron = clamp(c.getInt("armor.iron", 11), 1, 1000);
        r.armorDiamond = clamp(c.getInt("armor.diamond", 18), 1, 1000);
        r.armorNetherite = clamp(c.getInt("armor.netherite", 18), 1, 1000);

        r.bleedChance = clamp01(c.getDouble("bleeding.chance", 0.20));
        r.bleedMinDamage = Math.max(0.0, c.getDouble("bleeding.min-damage", 3.0));
        r.bleedDurationSeconds = clamp(c.getInt("bleeding.duration-seconds", 20), 1, 600);
        r.bleedIntervalSeconds = clamp(c.getInt("bleeding.interval-seconds", 5), 1, 600);
        r.bleedDamage = Math.max(0.0, c.getDouble("bleeding.damage", 1.0));
        r.bleedCanBeLethal = c.getBoolean("bleeding.can-be-lethal", false);
        r.bleedFromEnvironment = c.getBoolean("bleeding.from-environment", false);
        return r;
    }

    /** Armor gates only apply while aging is also on. */
    public boolean armorGatesActive() { return enableAging && enableArmorAgeGates; }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
    private static double clamp01(double v) { return Math.max(0.0, Math.min(1.0, v)); }
}
