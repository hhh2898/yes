package com.ruggedsurvival.paper.command;

import com.ruggedsurvival.paper.Items;
import com.ruggedsurvival.paper.RuggedSurvivalPlugin;
import com.ruggedsurvival.paper.aging.AgingModule;
import com.ruggedsurvival.paper.data.PlayerData;
import com.ruggedsurvival.paper.data.PlayerDataStore;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * /rugged status|setage|setthirst|give|reload  (permission rugged.admin, ops by default).
 * Mostly for testing: you can jump straight to age 12 instead of waiting 110 in-game days.
 */
public final class RuggedCommand implements CommandExecutor, TabCompleter {
    private final RuggedSurvivalPlugin plugin;

    private RuggedCommand(RuggedSurvivalPlugin plugin) { this.plugin = plugin; }

    public static void register(RuggedSurvivalPlugin plugin) {
        PluginCommand cmd = plugin.getCommand("rugged");
        if (cmd == null) return;
        RuggedCommand c = new RuggedCommand(plugin);
        cmd.setExecutor(c);
        cmd.setTabCompleter(c);
    }

    private void say(CommandSender s, String text, NamedTextColor color) { s.sendMessage(Component.text(text, color)); }

    /** The named player, or the sender if they are a player and gave no name. Reports a problem itself. */
    private Player target(CommandSender s, String[] args, int index) {
        if (args.length > index) {
            Player p = Bukkit.getPlayerExact(args[index]);
            if (p == null) say(s, "Player not found: " + args[index], NamedTextColor.RED);
            return p;
        }
        if (s instanceof Player p) return p;
        say(s, "Name a player.", NamedTextColor.RED);
        return null;
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] args) {
        if (args.length == 0) { say(s, "/rugged status|setage|setthirst|give|reload", NamedTextColor.GOLD); return true; }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                plugin.reloadSettings();
                say(s, "Config reloaded. (Recipes, axe durability and rock spawning need a restart.)", NamedTextColor.GREEN);
            }
            case "status" -> {
                Player p = target(s, args, 1);
                if (p == null) return true;
                PlayerData d = PlayerDataStore.get(p);
                double days = Math.round(d.ageProgress / AgingModule.TICKS_PER_DAY * 10) / 10.0;
                say(s, p.getName() + ": age " + d.age
                        + ", " + (int) (AgingModule.maxHealthFor(d.age, plugin.cfg()) / 2) + " hearts"
                        + ", thirst " + String.format(Locale.ROOT, "%.1f", d.thirst) + "/" + plugin.cfg().thirstCapacity
                        + ", " + days + "/" + plugin.cfg().daysPerAge + " days toward next age"
                        + (d.isBleeding() ? ", BLEEDING" : "") + (d.unsafeTicks > 0 ? ", unsafe water" : ""),
                        NamedTextColor.AQUA);
            }
            case "setage" -> {
                if (args.length < 3) { say(s, "/rugged setage <player> <age>", NamedTextColor.RED); return true; }
                Player p = target(s, args, 1);
                if (p == null) return true;
                try {
                    PlayerData d = PlayerDataStore.get(p);
                    d.age = Math.max(plugin.cfg().startingAge, Integer.parseInt(args[2]));
                    d.ageProgress = 0;
                    AgingModule.applyMaxHealth(p, false);
                    say(s, p.getName() + " is now age " + d.age + ".", NamedTextColor.GREEN);
                } catch (NumberFormatException ex) {
                    say(s, "Age must be a number.", NamedTextColor.RED);
                }
            }
            case "setthirst" -> {
                if (args.length < 3) { say(s, "/rugged setthirst <player> <points>", NamedTextColor.RED); return true; }
                Player p = target(s, args, 1);
                if (p == null) return true;
                try {
                    PlayerData d = PlayerDataStore.get(p);
                    d.thirst = Math.max(0, Math.min(plugin.cfg().thirstCapacity, Double.parseDouble(args[2])));
                    say(s, p.getName() + " thirst set to " + d.thirst + ".", NamedTextColor.GREEN);
                } catch (NumberFormatException ex) {
                    say(s, "Points must be a number.", NamedTextColor.RED);
                }
            }
            case "give" -> {
                if (args.length < 2 || !Items.ALL.contains(args[1])) {
                    say(s, "/rugged give <" + String.join("|", Items.ALL) + "> [player]", NamedTextColor.RED);
                    return true;
                }
                Player p = target(s, args, 2);
                if (p == null) return true;
                for (ItemStack rest : p.getInventory().addItem(Items.create(args[1], 1)).values()) {
                    p.getWorld().dropItemNaturally(p.getLocation(), rest);
                }
                say(s, "Gave " + args[1] + " to " + p.getName() + ".", NamedTextColor.GREEN);
            }
            default -> say(s, "Unknown subcommand.", NamedTextColor.RED);
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) out.addAll(List.of("status", "setage", "setthirst", "give", "reload"));
        else if (args.length == 2 && args[0].equalsIgnoreCase("give")) out.addAll(Items.ALL);
        else if (args.length == 2 || (args.length == 3 && args[0].equalsIgnoreCase("give")))
            Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        String last = args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(o -> !o.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
