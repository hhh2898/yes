package com.ruggedsurvival.paper.aging;

import com.ruggedsurvival.paper.RuggedSurvivalPlugin;
import com.ruggedsurvival.paper.config.RuggedConfig;
import com.ruggedsurvival.paper.data.PlayerData;
import com.ruggedsurvival.paper.data.PlayerDataStore;
import com.ruggedsurvival.paper.time.LongerDays;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.world.TimeSkipEvent;

/**
 * Age and max-health progression.
 *  - Age counts IN-GAME time: every tick adds the longer-days clock rate, so a longer day slows aging.
 *  - Sleeping through the night adds the skipped time (one age-up at most per skip).
 *  - Offline players are never ticked (unless count-offline-time is on).
 *  - Max health = starting hearts + (age - starting age), capped. Gaining a heart never heals.
 */
public final class AgingModule implements Listener {
    public static final double TICKS_PER_DAY = 24000.0;

    private final RuggedSurvivalPlugin plugin;

    private AgingModule(RuggedSurvivalPlugin plugin) { this.plugin = plugin; }

    public static void register(RuggedSurvivalPlugin plugin) {
        AgingModule m = new AgingModule(plugin);
        Bukkit.getPluginManager().registerEvents(m, plugin);
        Bukkit.getScheduler().runTaskTimer(plugin, m::tick, 1L, 1L);
    }

    // ---- pure rules ----

    /** Max health points (2 per heart) for an age. 20 (vanilla) when aging is off. */
    public static double maxHealthFor(int age, RuggedConfig c) {
        if (!c.enableAging) return 20.0;
        int hearts = Math.min(c.maxHearts, c.startingHearts + Math.max(0, age - c.startingAge));
        return hearts * 2.0;
    }

    /** In-game ticks needed for one age-up. */
    public static double ticksPerAge(RuggedConfig c) { return c.daysPerAge * TICKS_PER_DAY; }

    // ---- ticking ----

    private void tick() {
        RuggedConfig c = plugin.cfg();
        if (!c.enableAging) return;
        double rate = LongerDays.timeScale(c);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.isDead() || p.getGameMode() == GameMode.SPECTATOR) continue;
            advance(p, rate);
        }
    }

    /** A night skipped by sleeping counts as elapsed time (time commands and clock edits do not). */
    @EventHandler
    public void onTimeSkip(TimeSkipEvent e) {
        RuggedConfig c = plugin.cfg();
        if (!c.enableAging || e.getSkipReason() != TimeSkipEvent.SkipReason.NIGHT_SKIP) return;
        for (Player p : e.getWorld().getPlayers()) {
            if (!p.isDead() && p.getGameMode() != GameMode.SPECTATOR) advance(p, e.getSkipAmount());
        }
    }

    private void advance(Player p, double delta) {
        RuggedConfig c = plugin.cfg();
        PlayerData d = PlayerDataStore.get(p);
        if (c.ageCap > 0 && d.age >= c.ageCap) return; // capped players stop accumulating

        double needed = ticksPerAge(c);
        d.ageProgress += delta;
        if (d.ageProgress >= needed) {
            // Exactly ONE age-up, even after a long sleep skip; the leftover stays below one full
            // threshold so it can never chain into instant extra ages.
            d.ageProgress = Math.min(d.ageProgress - needed, needed - 1);
            d.age++;
            applyMaxHealth(p, false);
            p.sendMessage(Component.text("You are now age " + d.age + ". Your maximum health is "
                    + (int) (maxHealthFor(d.age, c) / 2.0) + " hearts.", NamedTextColor.GREEN));
        }
    }

    // ---- max health ----

    /** Set max health from age. Never heals on its own; it only clamps down (fullHeal only after death). */
    public static void applyMaxHealth(Player p, boolean fullHeal) {
        RuggedConfig c = RuggedSurvivalPlugin.get().cfg();
        double max = maxHealthFor(PlayerDataStore.get(p).age, c);
        AttributeInstance attr = p.getAttribute(Attribute.MAX_HEALTH);
        if (attr != null && attr.getBaseValue() != max) attr.setBaseValue(max);
        double cap = attr != null ? attr.getValue() : 20.0;
        if (fullHeal) p.setHealth(cap);
        else if (p.getHealth() > cap) p.setHealth(cap); // a config change lowered the maximum
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        RuggedConfig c = plugin.cfg();
        PlayerData d = PlayerDataStore.get(p);
        if (c.enableAging && c.countOfflineTime && d.lastSeen > 0) {
            double offlineTicks = (System.currentTimeMillis() - d.lastSeen) / 50.0;
            advance(p, offlineTicks * LongerDays.timeScale(c));
        }
        applyMaxHealth(p, false);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        // One tick later, so the new body exists and the death reset has been applied.
        Bukkit.getScheduler().runTask(plugin, () -> applyMaxHealth(p, true));
    }
}
