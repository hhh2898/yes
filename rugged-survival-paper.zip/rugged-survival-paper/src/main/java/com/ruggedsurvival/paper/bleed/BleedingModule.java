package com.ruggedsurvival.paper.bleed;

import com.ruggedsurvival.paper.Hud;
import com.ruggedsurvival.paper.Items;
import com.ruggedsurvival.paper.RuggedSurvivalPlugin;
import com.ruggedsurvival.paper.config.RuggedConfig;
import com.ruggedsurvival.paper.data.PlayerData;
import com.ruggedsurvival.paper.data.PlayerDataStore;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Bleeding.
 *  - A hit that deals >= min-damage (after armor) has a chance to start bleeding. Environmental
 *    damage (no attacker) is ignored unless from-environment is on.
 *  - Bleeding deals `damage` every `interval-seconds` for `duration-seconds` (defaults: 1 health point
 *    every 5 s for 20 s = 2 hearts). It never stacks; a new qualifying hit just refreshes the duration.
 *    By default it can never take you below 1 health.
 *  - A Bandage (right-click) stops it.
 * The state lives in PlayerData, so it survives logout/restart and does not tick while offline.
 */
public final class BleedingModule implements Listener {
    private final RuggedSurvivalPlugin plugin;

    private BleedingModule(RuggedSurvivalPlugin plugin) { this.plugin = plugin; }

    public static void register(RuggedSurvivalPlugin plugin) {
        BleedingModule m = new BleedingModule(plugin);
        Bukkit.getPluginManager().registerEvents(m, plugin);
        Bukkit.getScheduler().runTaskTimer(plugin, m::tick, 1L, 1L);
    }

    // ---- starting / refreshing ----

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        RuggedConfig c = plugin.cfg();
        if (!c.enableBleeding || p.isDead()) return;
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;

        double dealt = e.getFinalDamage();
        if (dealt < c.bleedMinDamage) return;
        if (p.getHealth() - dealt <= 0) return; // the hit killed them
        boolean environmental = !(e instanceof EntityDamageByEntityEvent); // attackers and projectiles are not
        if (environmental && !c.bleedFromEnvironment) return;
        if (ThreadLocalRandom.current().nextDouble() >= c.bleedChance) return;

        PlayerData d = PlayerDataStore.get(p);
        boolean already = d.isBleeding();
        d.bleedLeft = c.bleedDurationSeconds * 20;      // start or refresh; never stacks
        if (!already) { d.bleedCounter = 0; startCue(p); }
    }

    // ---- ticking ----

    private void tick() {
        RuggedConfig c = plugin.cfg();
        for (Player p : Bukkit.getOnlinePlayers()) {
            PlayerData d = PlayerDataStore.get(p);
            if (!c.enableBleeding) { d.bleedLeft = 0; d.bleedCounter = 0; continue; }
            if (!d.isBleeding() || p.isDead()) continue;

            d.bleedCounter++;
            if (d.bleedCounter >= c.bleedIntervalSeconds * 20) {
                d.bleedCounter = 0;
                bleedHurt(p, c);
                if (p.isDead()) continue;
            }
            if (--d.bleedLeft <= 0) { d.bleedLeft = 0; d.bleedCounter = 0; endCue(p); }
        }
    }

    private void bleedHurt(Player p, RuggedConfig c) {
        if (c.bleedCanBeLethal) {
            p.damage(c.bleedDamage);
        } else if (p.getHealth() > 1.0) {
            p.setHealth(Math.max(1.0, p.getHealth() - c.bleedDamage)); // never below 1 health
        }
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_HURT, 0.8f, 1.0f);
        drip(p);
    }

    // ---- bandage ----

    @EventHandler(priority = EventPriority.HIGH)
    public void onUseBandage(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = e.getItem();
        if (!Items.is(item, Items.BANDAGE) || !plugin.cfg().enableBleeding) return;
        e.setCancelled(true);

        Player p = e.getPlayer();
        PlayerData d = PlayerDataStore.get(p);
        if (!d.isBleeding()) { Hud.message(p, "You are not bleeding."); return; } // not used up

        d.bleedLeft = 0;
        d.bleedCounter = 0;
        if (p.getGameMode() != GameMode.CREATIVE) item.setAmount(item.getAmount() - 1);
        endCue(p);
    }

    // ---- feedback ----

    private void startCue(Player p) {
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_HURT, 1.0f, 0.8f);
        drip(p);
        Hud.message(p, "You are bleeding! Use a bandage.", NamedTextColor.RED);
    }

    private void endCue(Player p) {
        p.getWorld().playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.0f, 1.2f);
        Hud.message(p, "The bleeding has stopped.", NamedTextColor.GREEN);
    }

    private void drip(Player p) {
        Location at = p.getLocation().add(0, 1.0, 0);
        p.getWorld().spawnParticle(Particle.BLOCK, at, 8, 0.25, 0.4, 0.25, Material.REDSTONE_BLOCK.createBlockData());
    }
}
