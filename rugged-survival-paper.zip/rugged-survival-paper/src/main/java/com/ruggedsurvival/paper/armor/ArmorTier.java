package com.ruggedsurvival.paper.armor;

import com.ruggedsurvival.paper.config.RuggedConfig;
import org.bukkit.Material;

/** Gated vanilla armor tiers, recognised by material name. Modded/other armor is not gated. */
public enum ArmorTier {
    LEATHER("LEATHER_"), CHAINMAIL("CHAINMAIL_"), GOLD("GOLDEN_"),
    IRON("IRON_"), DIAMOND("DIAMOND_"), NETHERITE("NETHERITE_");

    private final String prefix;
    ArmorTier(String prefix) { this.prefix = prefix; }

    private static final String[] PIECES = {"HELMET", "CHESTPLATE", "LEGGINGS", "BOOTS"};

    /** Tier of a vanilla armor piece, or null if the material is not gated armor. */
    public static ArmorTier of(Material m) {
        if (m == null) return null;
        String n = m.name();
        for (ArmorTier t : values()) {
            if (!n.startsWith(t.prefix)) continue;
            String rest = n.substring(t.prefix.length());
            for (String piece : PIECES) if (rest.equals(piece)) return t;
        }
        return null;
    }

    /** Unlock age from the config. */
    public int unlockAge(RuggedConfig c) {
        return switch (this) {
            case LEATHER -> c.armorLeather;
            case CHAINMAIL -> c.armorChainmail;
            case GOLD -> c.armorGold;
            case IRON -> c.armorIron;
            case DIAMOND -> c.armorDiamond;
            case NETHERITE -> c.armorNetherite;
        };
    }
}
