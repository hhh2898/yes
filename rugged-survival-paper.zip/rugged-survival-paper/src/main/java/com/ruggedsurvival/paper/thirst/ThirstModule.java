package com.ruggedsurvival.paper.thirst;

import com.ruggedsurvival.paper.Items;
import com.ruggedsurvival.paper.RuggedSurvivalPlugin;
import com.ruggedsurvival.paper.config.RuggedConfig;
import com.ruggedsurvival.paper.data.PlayerData;
import com.ruggedsurvival.paper.data.PlayerDataStore;
import com.ruggedsurvival.paper.time.LongerDays;
import io.papermc.paper.event.player.PlayerJumpEvent;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Thirst.
 *  - Drains by in-game time (so longer days slow it); sprinting and jumping drain faster.
 *  - A plain Water Bottle (from water, the ocean or a cauldron) restores some thirst but applies
 *    Unsafe Water: faster drain and brief nausea, never direct damage.
 *  - Filtered Water (from the Water Filter) restores thirst safely.
 *  - At zero: Mining Fatigue, then Weakness after 30 seconds. No direct damage.
 */
public final class ThirstModule implements Listener {
    private static final int WEAKNESS_AFTER_TICKS = 600;

    private final RuggedSurvivalPlugin plugin;
    private final Map<UUID, Integer> zeroTicks = new HashMap<>();

    private ThirstModule(RuggedSurvivalPlugin plugin) { this.plugin = plugin; }

    public static void register(RuggedSurvivalPlugin plugin) {
        ThirstModule m = new ThirstModule(plugin);
        Bukkit.getPluginManager().registerEvents(m, plugin);
        Bukkit.getScheduler().runTaskTimer(plugin, m::tick, 1L, 1L);
    }

    private boolean affected(Player p) {
        GameMode g = p.getGameMode();
        return !p.isDead() && g != GameMode.CREATIVE && g != GameMode.SPECTATOR;
    }

    /** Restore thirst; unsafe = Unsafe Water debuff (faster drain + brief nausea). */
    public void drink(Player p, double amount, boolean unsafe) {
        RuggedConfig c = plugin.cfg();
        PlayerData d = PlayerDataStore.get(p);
        d.thirst = Math.min(c.thirstCapacity, d.thirst + amount);
        if (unsafe) {
            d.unsafeTicks = Math.max(d.unsafeTicks, c.unsafeWaterDurationSeconds * 20);
            if (c.unsafeWaterNausea) {
                p.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 100, 0, false, true, true));
            }
        }
    }

    @EventHandler
    public void onConsume(PlayerItemConsumeEvent e) {
        RuggedConfig c = plugin.cfg();
        if (!c.enableThirst) return;
        ItemStack it = e.getItem();
        if (it.getType() != Material.POTION) return;
        Player p = e.getPlayer();
        if (Items.is(it, Items.FILTERED_WATER)) {
            drink(p, c.filteredWaterRestore, false);
        } else if (Items.isUntreatedWaterBottle(it)) {
            drink(p, c.drinkFromSourceAmount, true);
        }
    }

    @EventHandler
    public void onJump(PlayerJumpEvent e) {
        RuggedConfig c = plugin.cfg();
        Player p = e.getPlayer();
        if (!c.enableThirst || !affected(p)) return;
        PlayerData d = PlayerDataStore.get(p);
        d.thirst = Math.max(0, d.thirst - c.thirstJumpCost * (d.unsafeTicks > 0 ? c.unsafeWaterDrainMultiplier : 1.0));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) { zeroTicks.remove(e.getPlayer().getUniqueId()); }

    private void tick() {
        RuggedConfig c = plugin.cfg();
        if (!c.enableThirst) return;
        double scale = LongerDays.timeScale(c);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!affected(p)) continue;
            PlayerData d = PlayerDataStore.get(p);

            double mult = c.thirstDrainMultiplier;
            if (p.isSprinting()) mult *= c.thirstSprintMultiplier;
            if (d.unsafeTicks > 0) mult *= c.unsafeWaterDrainMultiplier;

            d.thirst = Math.max(0, d.thirst - scale / c.thirstIdleTicksPerPoint * mult);
            if (d.unsafeTicks > 0) d.unsafeTicks--;

            penalties(p, d.thirst);
        }
    }

    private void penalties(Player p, double thirst) {
        UUID id = p.getUniqueId();
        if (thirst > 0) { zeroTicks.remove(id); return; }
        int z = zeroTicks.merge(id, 1, Integer::sum);
        if (z % 20 == 1) { // refresh each second with a short duration so it fades soon after drinking
            p.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 60, 0, true, false, true));
            if (z >= WEAKNESS_AFTER_TICKS) {
                p.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 60, 0, true, false, true));
            }
        }
    }
}
