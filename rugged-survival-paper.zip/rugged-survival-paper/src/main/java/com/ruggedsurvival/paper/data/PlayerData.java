package com.ruggedsurvival.paper.data;

import com.ruggedsurvival.paper.config.RuggedConfig;

/** One player's survival state. Saved on the player (persists across logout/restart). */
public final class PlayerData {
    public int age;
    /** In-game ticks accumulated toward the next age-up. */
    public double ageProgress;
    public double thirst;
    public int unsafeTicks;
    public int bleedLeft;
    public int bleedCounter;
    /** Real time (ms) the player last left; used only if count-offline-time is on. */
    public long lastSeen;

    public static PlayerData fresh(RuggedConfig c) {
        PlayerData d = new PlayerData();
        d.age = c.startingAge;
        d.thirst = c.thirstCapacity;
        return d;
    }

    public boolean isBleeding() { return bleedLeft > 0; }

    /** What carries over a death, per config. Bleeding and Unsafe Water never do. */
    public void afterDeath(RuggedConfig c) {
        if (c.resetAgeOnDeath) { age = c.startingAge; ageProgress = 0; }
        if (c.resetThirstOnDeath) thirst = c.thirstCapacity;
        unsafeTicks = 0;
        bleedLeft = 0;
        bleedCounter = 0;
    }

    /** Fix up loaded values (config limits may have changed since they were saved). */
    public void sanitize(RuggedConfig c) {
        age = Math.max(c.startingAge, age);
        if (c.ageCap > 0) age = Math.min(age, c.ageCap);
        thirst = Math.max(0, Math.min(c.thirstCapacity, thirst));
        ageProgress = Math.max(0, ageProgress);
        unsafeTicks = Math.max(0, unsafeTicks);
        bleedLeft = Math.max(0, bleedLeft);
        bleedCounter = Math.max(0, bleedCounter);
    }
}
