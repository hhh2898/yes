package com.ruggedsurvival.paper;

import com.ruggedsurvival.paper.aging.AgingModule;
import com.ruggedsurvival.paper.armor.ArmorGate;
import com.ruggedsurvival.paper.bleed.BleedingModule;
import com.ruggedsurvival.paper.command.RuggedCommand;
import com.ruggedsurvival.paper.config.RuggedConfig;
import com.ruggedsurvival.paper.data.PlayerDataStore;
import com.ruggedsurvival.paper.filter.WaterFilterModule;
import com.ruggedsurvival.paper.gather.TreeGatheringModule;
import com.ruggedsurvival.paper.thirst.ThirstModule;
import com.ruggedsurvival.paper.time.LongerDays;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

/** Rugged Survival (Paper). Server-side only: players join with an ordinary vanilla client. */
public final class RuggedSurvivalPlugin extends JavaPlugin implements Listener {

    private static RuggedSurvivalPlugin instance;
    private RuggedConfig cfg;

    public static RuggedSurvivalPlugin get() { return instance; }
    public RuggedConfig cfg() { return cfg; }

    @Override
    public void onEnable() {
        instance = this;
        getLogger().info("[Rugged Survival] starting up...");

        saveDefaultConfig();                         // writes config.yml on first run
        getConfig().options().copyDefaults(true);    // adds any new keys to an older file
        saveConfig();
        reloadSettings();
        Items.init(this);
        getLogger().info("[Rugged Survival] config loaded.");

        // Each module starts on its own, so one failure is named in the log and cannot stop the rest.
        safely("player data", () -> PlayerDataStore.register(this));
        safely("aging", () -> AgingModule.register(this));
        safely("armor gates", () -> ArmorGate.register(this));
        safely("longer days", () -> LongerDays.register(this));
        safely("recipes", () -> Recipes.register(this));
        safely("thirst", () -> ThirstModule.register(this));
        safely("water filter", () -> WaterFilterModule.register(this));
        safely("action bar", () -> Hud.register(this));
        safely("tree gathering", () -> TreeGatheringModule.register(this));
        safely("bleeding", () -> BleedingModule.register(this));
        safely("admin command", () -> RuggedCommand.register(this));
        safely("join message", () -> getServer().getPluginManager().registerEvents(this, this));

        getLogger().info("[Rugged Survival] finished starting.");
    }

    @Override
    public void onDisable() {
        PlayerDataStore.saveAll(); // keep everyone's progress on shutdown
    }

    /** Re-read config.yml into the typed settings. */
    public void reloadSettings() {
        reloadConfig();
        cfg = RuggedConfig.load(getConfig());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (cfg.showJoinMessage) {
            e.getPlayer().sendMessage(Component.text(
                    "[Rugged Survival] plugin is active. (Turn this message off with show-join-message in config.yml.)",
                    NamedTextColor.GOLD));
        }
    }

    private void safely(String module, Runnable start) {
        try {
            start.run();
            getLogger().info("[Rugged Survival] module OK: " + module);
        } catch (Throwable t) {
            getLogger().log(java.util.logging.Level.SEVERE, "[Rugged Survival] module FAILED: " + module, t);
        }
    }
}
