package com.ruggedsurvival.paper.time;

import com.ruggedsurvival.paper.RuggedSurvivalPlugin;
import com.ruggedsurvival.paper.config.RuggedConfig;
import org.bukkit.Bukkit;
import org.bukkit.World;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Longer days: slows the overworld clock to 20 / day-length-minutes of normal speed
 * (20 minutes = vanilla, 30 = two thirds speed, 60 = one third).
 *
 * Every tick we see the clock moved +1 (vanilla) and replace that with the slower step, keeping the
 * fractional part so it stays exact over time. Frozen time (daylight cycle off), sleeping and
 * /time set are all left alone because they do not look like a plain +1 tick.
 * Game speed (mobs, redstone, crops) is untouched. Aging and thirst use {@link #timeScale} so they
 * slow by the same factor. Every player shares the one world clock.
 */
public final class LongerDays {
    private LongerDays() {}

    private static final class State {
        long lastSet;
        double frac;
        State(long t) { lastSet = t; }
    }

    private static final Map<UUID, State> states = new HashMap<>();

    /** In-game ticks per game tick: 1.0 normally, 20 / day-length-minutes when longer days are on. */
    public static double timeScale(RuggedConfig c) {
        return c.enableLongerDays ? Math.min(1.0, 20.0 / c.dayLengthMinutes) : 1.0;
    }

    public static void register(RuggedSurvivalPlugin plugin) {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            RuggedConfig c = plugin.cfg();
            double rate = timeScale(c);
            if (!c.enableLongerDays || rate >= 0.9999) return; // off, or 20 minutes = vanilla speed
            for (World w : Bukkit.getWorlds()) {
                if (w.getEnvironment() != World.Environment.NORMAL) continue; // only the overworld has days
                step(w, rate);
            }
        }, 1L, 1L);
    }

    private static void step(World w, double rate) {
        long cur = w.getFullTime();
        State s = states.computeIfAbsent(w.getUID(), k -> new State(cur));
        long delta = cur - s.lastSet;
        if (delta == 1) {                       // a normal vanilla tick: swap in the slower step
            double next = s.lastSet + s.frac + rate;
            long target = (long) Math.floor(next);
            s.frac = next - target;
            if (target != cur) w.setFullTime(target);
            s.lastSet = target;
        } else {                                // frozen, slept through, or set by a command: leave it alone
            s.lastSet = cur;
            s.frac = 0;
        }
    }
}
