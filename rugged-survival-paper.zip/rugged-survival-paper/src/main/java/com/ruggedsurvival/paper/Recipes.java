package com.ruggedsurvival.paper;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Tag;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.ShapelessRecipe;

import java.util.ArrayList;
import java.util.List;

/** Crafting recipes for the custom items. Players are shown them in the recipe book on join. */
public final class Recipes implements Listener {
    private final List<NamespacedKey> keys = new ArrayList<>();

    public static void register(RuggedSurvivalPlugin plugin) {
        Recipes r = new Recipes();
        r.add(plugin, "water_filter", filter(plugin));
        r.add(plugin, "filter_media", media(plugin));
        r.add(plugin, "crude_handaxe", handaxe(plugin));
        r.add(plugin, "bandage_paper", bandagePaper(plugin));
        r.add(plugin, "bandage_wool", bandageWool(plugin));
        Bukkit.getPluginManager().registerEvents(r, plugin);
    }

    private void add(RuggedSurvivalPlugin plugin, String name, Recipe recipe) {
        NamespacedKey k = new NamespacedKey(plugin, name);
        Bukkit.removeRecipe(k);       // safe on /reload
        Bukkit.addRecipe(recipe);
        keys.add(k);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) { e.getPlayer().discoverRecipes(keys); }

    /** 6 cobblestone, 2 sand, 1 charcoal: no iron needed. */
    private static Recipe filter(RuggedSurvivalPlugin pl) {
        ShapedRecipe r = new ShapedRecipe(new NamespacedKey(pl, "water_filter"), Items.create(Items.WATER_FILTER, 1));
        r.shape("CCC", "SKS", "CCC");
        r.setIngredient('C', Material.COBBLESTONE);
        r.setIngredient('S', Material.SAND);
        r.setIngredient('K', Material.CHARCOAL);
        return r;
    }

    /** Charcoal + sand + gravel makes 2 Filter Media. */
    private static Recipe media(RuggedSurvivalPlugin pl) {
        ShapelessRecipe r = new ShapelessRecipe(new NamespacedKey(pl, "filter_media"), Items.create(Items.FILTER_MEDIA, 2));
        r.addIngredient(Material.CHARCOAL);
        r.addIngredient(Material.SAND);
        r.addIngredient(Material.GRAVEL);
        return r;
    }

    /** 3 Loose Rocks + 1 stick (a 2x2 recipe). */
    private static Recipe handaxe(RuggedSurvivalPlugin pl) {
        ShapedRecipe r = new ShapedRecipe(new NamespacedKey(pl, "crude_handaxe"), Items.create(Items.CRUDE_HANDAXE, 1));
        r.shape("RR", "RS");
        r.setIngredient('R', new RecipeChoice.ExactChoice(Items.create(Items.LOOSE_ROCK, 1)));
        r.setIngredient('S', Material.STICK);
        return r;
    }

    /** Plain paper only (ExactChoice), so a bandage can never be re-crafted into more bandages. */
    private static Recipe bandagePaper(RuggedSurvivalPlugin pl) {
        ShapelessRecipe r = new ShapelessRecipe(new NamespacedKey(pl, "bandage_paper"), Items.create(Items.BANDAGE, 2));
        r.addIngredient(new RecipeChoice.ExactChoice(new ItemStack(Material.PAPER)));
        r.addIngredient(Material.STRING);
        return r;
    }

    /** Any wool + string makes 3 bandages (the "cloth" option). */
    private static Recipe bandageWool(RuggedSurvivalPlugin pl) {
        ShapelessRecipe r = new ShapelessRecipe(new NamespacedKey(pl, "bandage_wool"), Items.create(Items.BANDAGE, 3));
        r.addIngredient(new RecipeChoice.MaterialChoice(Tag.WOOL));
        r.addIngredient(Material.STRING);
        return r;
    }

}
