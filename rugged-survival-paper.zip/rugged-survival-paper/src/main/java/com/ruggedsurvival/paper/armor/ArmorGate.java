package com.ruggedsurvival.paper.armor;

import com.ruggedsurvival.paper.Hud;
import com.ruggedsurvival.paper.RuggedSurvivalPlugin;
import com.ruggedsurvival.paper.config.RuggedConfig;
import com.ruggedsurvival.paper.data.PlayerDataStore;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Age-gated armor.
 *  - Right-click equipping, armor-slot clicks, shift-clicks and hotbar swaps of too-heavy armor are blocked.
 *  - Every half second any worn piece above the player's age is taken off and returned to the
 *    inventory (dropped at their feet if it is full, never deleted). This also covers dispensers,
 *    other plugins, and armor made too heavy by a death reset (e.g. with keepInventory).
 *  - Gated armor in a player's inventory gets a "Requires age N" lore line (their tooltip).
 * Everything is off when aging or armor-age-gates is off.
 */
public final class ArmorGate implements Listener {
    private final RuggedSurvivalPlugin plugin;

    private ArmorGate(RuggedSurvivalPlugin plugin) { this.plugin = plugin; }

    public static void register(RuggedSurvivalPlugin plugin) {
        ArmorGate g = new ArmorGate(plugin);
        Bukkit.getPluginManager().registerEvents(g, plugin);
        Bukkit.getScheduler().runTaskTimer(plugin, g::scan, 20L, 10L);
    }

    /** Age needed for this stack; 0 if it is not gated armor or gates are off. */
    private int requiredAge(ItemStack s) {
        RuggedConfig c = plugin.cfg();
        if (s == null || !c.armorGatesActive()) return 0;
        ArmorTier t = ArmorTier.of(s.getType());
        return t == null ? 0 : t.unlockAge(c);
    }

    private boolean tooHeavy(Player p, ItemStack s) {
        int need = requiredAge(s);
        return need > 0 && PlayerDataStore.get(p).age < need;
    }

    private void warn(Player p, ItemStack s) {
        Hud.message(p, "You are too young to wear that. It requires age " + requiredAge(s)
                + " (you are age " + PlayerDataStore.get(p).age + ").", NamedTextColor.RED);
    }

    // ---- blocking the equip ----

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onUse(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = e.getItem();
        if (item != null && tooHeavy(e.getPlayer(), item)) {
            e.setCancelled(true);
            warn(e.getPlayer(), item);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p) || !plugin.cfg().armorGatesActive()) return;
        boolean armorSlot = e.getSlotType() == InventoryType.SlotType.ARMOR;
        ItemStack cursor = e.getCursor();
        ItemStack current = e.getCurrentItem();
        ItemStack blocked = null;

        if (armorSlot && cursor != null && tooHeavy(p, cursor)) {
            blocked = cursor;                                                   // dropping onto an armor slot
        } else if (e.isShiftClick() && !armorSlot && current != null && tooHeavy(p, current)) {
            blocked = current;                                                  // shift-click would equip it
        } else if (armorSlot && e.getClick() == ClickType.NUMBER_KEY) {         // hotbar-key swap
            ItemStack hot = p.getInventory().getItem(e.getHotbarButton());
            if (hot != null && tooHeavy(p, hot)) blocked = hot;
        }
        if (blocked != null) {
            e.setCancelled(true);
            warn(p, blocked);
        }
    }

    // ---- periodic enforcement + tooltips ----

    private void scan() {
        if (!plugin.cfg().armorGatesActive()) return;
        for (Player p : Bukkit.getOnlinePlayers()) {
            PlayerInventory inv = p.getInventory();
            enforce(p, inv.getHelmet(), inv::setHelmet);
            enforce(p, inv.getChestplate(), inv::setChestplate);
            enforce(p, inv.getLeggings(), inv::setLeggings);
            enforce(p, inv.getBoots(), inv::setBoots);
            stampLore(inv);
        }
    }

    private void enforce(Player p, ItemStack worn, Consumer<ItemStack> setter) {
        if (worn == null || !tooHeavy(p, worn)) return;
        setter.accept(null);
        warn(p, worn);
        Map<Integer, ItemStack> left = p.getInventory().addItem(worn);
        for (ItemStack rest : left.values()) p.getWorld().dropItemNaturally(p.getLocation(), rest); // never delete
    }

    private void stampLore(PlayerInventory inv) {
        RuggedConfig c = plugin.cfg();
        PlainTextComponentSerializer plain = PlainTextComponentSerializer.plainText();
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack it = inv.getItem(i);
            if (it == null) continue;
            ArmorTier t = ArmorTier.of(it.getType());
            if (t == null) continue;

            String wanted = "Requires age " + t.unlockAge(c);
            List<Component> old = it.lore();
            boolean has = false, other = false;
            if (old != null) {
                for (Component line : old) {
                    String s = plain.serialize(line);
                    if (s.equals(wanted)) has = true;
                    else if (s.startsWith("Requires age")) other = true;
                }
            }
            if (has && !other) continue; // already correct

            List<Component> lore = new ArrayList<>();
            if (old != null) for (Component line : old) if (!plain.serialize(line).startsWith("Requires age")) lore.add(line);
            lore.add(Component.text(wanted, NamedTextColor.GOLD).decoration(TextDecoration.ITALIC, false));
            it.lore(lore);
            inv.setItem(i, it);
        }
    }
}
