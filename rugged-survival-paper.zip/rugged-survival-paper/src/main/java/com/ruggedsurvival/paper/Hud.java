package com.ruggedsurvival.paper;

import com.ruggedsurvival.paper.data.PlayerData;
import com.ruggedsurvival.paper.data.PlayerDataStore;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Action-bar display (no client mod needed): thirst bar + a BLEEDING warning.
 * Other modules show short messages through {@link #message}, which pauses the bar briefly so
 * the message is not overwritten at once.
 */
public final class Hud {
    private Hud() {}

    private static final Map<UUID, Integer> mutedUntil = new HashMap<>();

    public static void register(RuggedSurvivalPlugin plugin) {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            int now = Bukkit.getCurrentTick();
            var cfg = plugin.cfg();
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) continue;
                if (mutedUntil.getOrDefault(p.getUniqueId(), 0) > now) continue;
                PlayerData d = PlayerDataStore.get(p);

                Component bar = null;
                if (cfg.enableThirst) {
                    int total = 10;
                    int filled = (int) Math.round(d.thirst / cfg.thirstCapacity * total);
                    filled = Math.max(0, Math.min(total, filled));
                    bar = Component.text("Thirst ", NamedTextColor.AQUA)
                            .append(Component.text("|".repeat(filled), d.unsafeTicks > 0 ? NamedTextColor.GREEN : NamedTextColor.BLUE))
                            .append(Component.text("|".repeat(total - filled), NamedTextColor.DARK_GRAY));
                }
                if (cfg.enableBleeding && d.isBleeding()) {
                    Component b = Component.text("BLEEDING", NamedTextColor.RED);
                    bar = bar == null ? b : bar.append(Component.text("   ")).append(b);
                }
                if (bar != null) p.sendActionBar(bar);
            }
        }, 20L, 10L);
        Bukkit.getScheduler().runTaskTimer(plugin, () -> mutedUntil.keySet().removeIf(id -> Bukkit.getPlayer(id) == null), 1200L, 1200L);
    }

    /** Show a short action-bar message and keep the HUD from covering it for ~2.5 seconds. */
    public static void message(Player p, String text, NamedTextColor color) {
        p.sendActionBar(Component.text(text, color));
        mutedUntil.put(p.getUniqueId(), Bukkit.getCurrentTick() + 50);
    }

    public static void message(Player p, String text) { message(p, text, NamedTextColor.GOLD); }
}
