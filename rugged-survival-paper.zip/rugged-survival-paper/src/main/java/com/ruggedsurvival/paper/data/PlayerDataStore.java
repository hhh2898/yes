package com.ruggedsurvival.paper.data;

import com.ruggedsurvival.paper.RuggedSurvivalPlugin;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Keeps each online player's {@link PlayerData} in memory and saves it into the player's own
 * persistent data on quit, every 5 minutes, and on shutdown. Offline players are never ticked,
 * so their age and thirst never move while they are away.
 */
public final class PlayerDataStore implements Listener {
    private static PlayerDataStore instance;

    private final RuggedSurvivalPlugin plugin;
    private final Map<UUID, PlayerData> cache = new HashMap<>();
    private final NamespacedKey kAge, kProgress, kThirst, kUnsafe, kBleedLeft, kBleedCounter, kLastSeen;

    private PlayerDataStore(RuggedSurvivalPlugin plugin) {
        this.plugin = plugin;
        kAge = new NamespacedKey(plugin, "age");
        kProgress = new NamespacedKey(plugin, "age_progress");
        kThirst = new NamespacedKey(plugin, "thirst");
        kUnsafe = new NamespacedKey(plugin, "unsafe_ticks");
        kBleedLeft = new NamespacedKey(plugin, "bleed_left");
        kBleedCounter = new NamespacedKey(plugin, "bleed_counter");
        kLastSeen = new NamespacedKey(plugin, "last_seen");
    }

    public static void register(RuggedSurvivalPlugin plugin) {
        instance = new PlayerDataStore(plugin);
        Bukkit.getPluginManager().registerEvents(instance, plugin);
        Bukkit.getScheduler().runTaskTimer(plugin, PlayerDataStore::saveAll, 6000L, 6000L);
        // Players already online (e.g. after /reload) get their data loaded right away.
        for (Player p : Bukkit.getOnlinePlayers()) instance.cache.put(p.getUniqueId(), instance.load(p));
    }

    /** This player's state (loaded on first use). */
    public static PlayerData get(Player p) {
        return instance.cache.computeIfAbsent(p.getUniqueId(), id -> instance.load(p));
    }

    /** Write every online player's state to their saved data. */
    public static void saveAll() {
        if (instance == null) return;
        for (Player p : Bukkit.getOnlinePlayers()) {
            PlayerData d = instance.cache.get(p.getUniqueId());
            if (d != null) instance.write(p, d);
        }
    }

    private PlayerData load(Player p) {
        PersistentDataContainer pdc = p.getPersistentDataContainer();
        PlayerData d = PlayerData.fresh(plugin.cfg());
        d.age = pdc.getOrDefault(kAge, PersistentDataType.INTEGER, d.age);
        d.ageProgress = pdc.getOrDefault(kProgress, PersistentDataType.DOUBLE, 0.0);
        d.thirst = pdc.getOrDefault(kThirst, PersistentDataType.DOUBLE, d.thirst);
        d.unsafeTicks = pdc.getOrDefault(kUnsafe, PersistentDataType.INTEGER, 0);
        d.bleedLeft = pdc.getOrDefault(kBleedLeft, PersistentDataType.INTEGER, 0);
        d.bleedCounter = pdc.getOrDefault(kBleedCounter, PersistentDataType.INTEGER, 0);
        d.lastSeen = pdc.getOrDefault(kLastSeen, PersistentDataType.LONG, 0L);
        d.sanitize(plugin.cfg());
        return d;
    }

    private void write(Player p, PlayerData d) {
        PersistentDataContainer pdc = p.getPersistentDataContainer();
        pdc.set(kAge, PersistentDataType.INTEGER, d.age);
        pdc.set(kProgress, PersistentDataType.DOUBLE, d.ageProgress);
        pdc.set(kThirst, PersistentDataType.DOUBLE, d.thirst);
        pdc.set(kUnsafe, PersistentDataType.INTEGER, d.unsafeTicks);
        pdc.set(kBleedLeft, PersistentDataType.INTEGER, d.bleedLeft);
        pdc.set(kBleedCounter, PersistentDataType.INTEGER, d.bleedCounter);
        pdc.set(kLastSeen, PersistentDataType.LONG, d.lastSeen);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onJoin(PlayerJoinEvent e) {
        cache.put(e.getPlayer().getUniqueId(), load(e.getPlayer()));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) {
        PlayerData d = cache.remove(e.getPlayer().getUniqueId());
        if (d != null) {
            d.lastSeen = System.currentTimeMillis();
            write(e.getPlayer(), d);
        }
    }

    /** Death resets age (and thirst, per config) and clears bleeding. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent e) {
        get(e.getEntity()).afterDeath(plugin.cfg());
    }
}
