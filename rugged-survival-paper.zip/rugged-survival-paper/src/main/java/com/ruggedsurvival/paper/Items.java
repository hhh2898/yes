package com.ruggedsurvival.paper;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionType;

import java.util.List;

/**
 * The plugin's "custom" items. Players have a vanilla client, so each one is a vanilla item with a
 * custom name and a hidden tag (PersistentDataContainer) that the plugin looks for.
 */
public final class Items {
    private Items() {}

    public static final String LOOSE_ROCK = "loose_rock";
    public static final String WATER_FILTER = "water_filter";
    public static final String FILTER_MEDIA = "filter_media";
    public static final String FILTERED_WATER = "filtered_water";
    public static final String BANDAGE = "bandage";
    public static final String CRUDE_HANDAXE = "crude_handaxe";
    public static final List<String> ALL = List.of(LOOSE_ROCK, WATER_FILTER, FILTER_MEDIA, FILTERED_WATER, BANDAGE, CRUDE_HANDAXE);

    private static NamespacedKey key;

    public static void init(JavaPlugin plugin) { key = new NamespacedKey(plugin, "item"); }

    /** The tag id of a custom item, or null for any normal item. */
    public static String idOf(ItemStack s) {
        if (s == null || s.getType().isAir() || !s.hasItemMeta()) return null;
        return s.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
    }

    public static boolean is(ItemStack s, String id) { return id.equals(idOf(s)); }

    /** A plain vanilla Water Bottle (what you get from water or a cauldron): untreated. */
    public static boolean isUntreatedWaterBottle(ItemStack s) {
        if (s == null || s.getType() != Material.POTION || idOf(s) != null) return false;
        return s.getItemMeta() instanceof PotionMeta pm && pm.getBasePotionType() == PotionType.WATER;
    }

    private static Component name(String text, NamedTextColor color) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
    }

    private static List<Component> lore(String... lines) {
        return java.util.Arrays.stream(lines)
                .map(l -> (Component) Component.text(l, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false))
                .toList();
    }

    public static ItemStack create(String id, int amount) {
        ItemStack stack;
        switch (id) {
            case LOOSE_ROCK -> {
                stack = new ItemStack(Material.FLINT, amount);
                stack.editMeta(m -> { m.displayName(name("Loose Rock", NamedTextColor.GRAY));
                    m.lore(lore("A small rock.", "Three rocks and a stick make a crude handaxe.")); tag(m, id); });
            }
            case WATER_FILTER -> {
                stack = new ItemStack(Material.CAULDRON, amount);
                stack.editMeta(m -> { m.displayName(name("Water Filter", NamedTextColor.AQUA));
                    m.lore(lore("Place it, load Filter Media,", "then right-click with a Water Bottle.")); tag(m, id); });
            }
            case FILTER_MEDIA -> {
                stack = new ItemStack(Material.BLACK_DYE, amount);
                stack.editMeta(m -> { m.displayName(name("Filter Media", NamedTextColor.DARK_GRAY));
                    m.lore(lore("Right-click a Water Filter to load it.")); tag(m, id); });
            }
            case FILTERED_WATER -> {
                stack = new ItemStack(Material.POTION, amount);
                stack.editMeta(PotionMeta.class, m -> { m.setBasePotionType(PotionType.WATER);
                    m.setColor(Color.fromRGB(110, 200, 255));
                    m.displayName(name("Filtered Water", NamedTextColor.AQUA));
                    m.lore(lore("Safe to drink.")); tag(m, id); });
            }
            case BANDAGE -> {
                stack = new ItemStack(Material.PAPER, amount);
                stack.editMeta(m -> { m.displayName(name("Bandage", NamedTextColor.WHITE));
                    m.lore(lore("Right-click to stop bleeding.")); tag(m, id); });
            }
            case CRUDE_HANDAXE -> {
                stack = new ItemStack(Material.WOODEN_AXE, amount);
                int dur = RuggedSurvivalPlugin.get().cfg().crudeHandaxeDurability;
                stack.editMeta(m -> { m.displayName(name("Crude Handaxe", NamedTextColor.GRAY));
                    m.lore(lore("Slow and fragile, but it can chop logs."));
                    if (m instanceof Damageable d) d.setMaxDamage(dur);
                    tag(m, id); });
            }
            default -> throw new IllegalArgumentException("Unknown item id: " + id);
        }
        return stack;
    }

    private static void tag(org.bukkit.inventory.meta.ItemMeta m, String id) {
        m.getPersistentDataContainer().set(key, PersistentDataType.STRING, id);
    }
}
