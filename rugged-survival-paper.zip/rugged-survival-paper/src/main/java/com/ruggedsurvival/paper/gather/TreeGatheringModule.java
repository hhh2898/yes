package com.ruggedsurvival.paper.gather;

import com.ruggedsurvival.paper.Hud;
import com.ruggedsurvival.paper.Items;
import com.ruggedsurvival.paper.RuggedSurvivalPlugin;
import com.ruggedsurvival.paper.config.RuggedConfig;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.GameMode;
import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Tool-gated tree gathering plus the starter supply that keeps it fair.
 *  1. Bare hands cannot break logs: starting to punch one is cancelled and hurts (never lethal, with a cooldown).
 *  2. Loose Rocks (flint named "Loose Rock") lie on the ground in newly generated overworld chunks.
 *  3. Fallback so NO world can soft-lock: breaking dirt/sand/gravel/grass sometimes drops a Loose Rock,
 *     and short grass / ferns sometimes drop a stick. (Leaves already drop sticks in vanilla.)
 */
public final class TreeGatheringModule implements Listener {
    private static final Set<Material> ROCK_BLOCKS = EnumSet.of(Material.DIRT, Material.GRASS_BLOCK,
            Material.COARSE_DIRT, Material.PODZOL, Material.GRAVEL, Material.SAND, Material.RED_SAND, Material.MUD);
    private static final Set<Material> STICK_BLOCKS = EnumSet.of(Material.SHORT_GRASS, Material.FERN);

    private final RuggedSurvivalPlugin plugin;
    private final Map<UUID, Integer> lastHurt = new HashMap<>();

    private TreeGatheringModule(RuggedSurvivalPlugin plugin) { this.plugin = plugin; }

    public static void register(RuggedSurvivalPlugin plugin) {
        Bukkit.getPluginManager().registerEvents(new TreeGatheringModule(plugin), plugin);
    }

    // ---- bare hands on logs ----

    private boolean isBareHandOnLog(Player p, Block b) {
        if (!plugin.cfg().enableTreeRestrictions) return false;
        GameMode g = p.getGameMode();
        if (g == GameMode.CREATIVE || g == GameMode.SPECTATOR) return false;
        return p.getInventory().getItemInMainHand().getType().isAir() && Tag.LOGS.isTagged(b.getType());
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onStartMining(BlockDamageEvent e) {
        if (!isBareHandOnLog(e.getPlayer(), e.getBlock())) return;
        e.setCancelled(true);
        hurtHand(e.getPlayer());
    }

    /** Safety net for anything that still reaches an actual break. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreakAttempt(BlockBreakEvent e) {
        if (isBareHandOnLog(e.getPlayer(), e.getBlock())) e.setCancelled(true);
    }

    private void hurtHand(Player p) {
        RuggedConfig c = plugin.cfg();
        int now = p.getTicksLived();
        if (now - lastHurt.getOrDefault(p.getUniqueId(), -100000) < c.bareHandLogCooldownTicks) return;
        lastHurt.put(p.getUniqueId(), now);

        // Never lethal: the injury is a lesson, not a death trap.
        if (c.bareHandLogDamage > 0 && p.getHealth() > c.bareHandLogDamage) p.damage(c.bareHandLogDamage);
        Hud.message(p, "Punching a log with bare hands hurts. You need a tool.", NamedTextColor.RED);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) { lastHurt.remove(e.getPlayer().getUniqueId()); }

    // ---- fallback drops so nobody is stuck ----

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBroken(BlockBreakEvent e) {
        if (e.getPlayer().getGameMode() != GameMode.SURVIVAL) return;
        RuggedConfig c = plugin.cfg();
        Material m = e.getBlock().getType();
        ThreadLocalRandom r = ThreadLocalRandom.current();
        Location at = e.getBlock().getLocation().add(0.5, 0.5, 0.5);
        if (ROCK_BLOCKS.contains(m) && r.nextDouble() < c.looseRockFallbackChance) {
            e.getBlock().getWorld().dropItemNaturally(at, Items.create(Items.LOOSE_ROCK, 1));
        } else if (STICK_BLOCKS.contains(m) && r.nextDouble() < c.looseStickFallbackChance) {
            e.getBlock().getWorld().dropItemNaturally(at, new ItemStack(Material.STICK));
        }
    }

    // ---- loose rocks lying in newly generated chunks ----

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent e) {
        double rate = plugin.cfg().looseRockSpawnRate;
        if (!e.isNewChunk() || rate <= 0 || e.getWorld().getEnvironment() != World.Environment.NORMAL) return;
        Chunk chunk = e.getChunk();
        // Next tick: entities cannot safely be spawned in the middle of chunk loading.
        Bukkit.getScheduler().runTask(plugin, () -> { if (chunk.isLoaded()) scatterRocks(chunk, rate); });
    }

    private void scatterRocks(Chunk chunk, double rate) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        World w = chunk.getWorld();
        double chance = Math.min(0.95, rate * 0.6);
        int placed = 0;
        while (placed < 4 && r.nextDouble() < chance) {
            chance *= 0.5;
            int x = chunk.getX() * 16 + r.nextInt(16);
            int z = chunk.getZ() * 16 + r.nextInt(16);
            int y = w.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
            Block ground = w.getBlockAt(x, y, z);
            if (!ground.getType().isSolid() || Tag.LEAVES.isTagged(ground.getType())) continue;
            Location at = new Location(w, x + 0.5, y + 1.0, z + 0.5);
            w.dropItem(at, Items.create(Items.LOOSE_ROCK, 1), item -> {
                item.setUnlimitedLifetime(true); // rocks stay put instead of despawning after 5 minutes
                item.setVelocity(new Vector(0, 0, 0));
            });
            placed++;
        }
    }
}
