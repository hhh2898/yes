package com.ruggedsurvival.paper.filter;

import com.ruggedsurvival.paper.RuggedSurvivalPlugin;
import org.bukkit.Chunk;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.persistence.PersistentDataType;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Remembers which cauldrons are Water Filters and how many bottles each has left. Saved inside the
 * chunk itself ("x,y,z=charges;..."), so it survives restarts and moves with the world.
 */
public final class FilterStore {
    private final NamespacedKey key;

    public FilterStore(RuggedSurvivalPlugin plugin) { key = new NamespacedKey(plugin, "filters"); }

    private static String pos(Block b) { return b.getX() + "," + b.getY() + "," + b.getZ(); }

    private Map<String, Integer> read(Chunk c) {
        Map<String, Integer> m = new LinkedHashMap<>();
        String raw = c.getPersistentDataContainer().getOrDefault(key, PersistentDataType.STRING, "");
        if (raw.isEmpty()) return m;
        for (String part : raw.split(";")) {
            int eq = part.indexOf('=');
            if (eq < 0) continue;
            try { m.put(part.substring(0, eq), Integer.parseInt(part.substring(eq + 1))); }
            catch (NumberFormatException ignored) { }
        }
        return m;
    }

    private void write(Chunk c, Map<String, Integer> m) {
        if (m.isEmpty()) { c.getPersistentDataContainer().remove(key); return; }
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> en : m.entrySet()) {
            if (sb.length() > 0) sb.append(';');
            sb.append(en.getKey()).append('=').append(en.getValue());
        }
        c.getPersistentDataContainer().set(key, PersistentDataType.STRING, sb.toString());
    }

    /** Bottles left, or null if this block is not a Water Filter. */
    public Integer get(Block b) { return read(b.getChunk()).get(pos(b)); }

    public boolean isFilter(Block b) { return get(b) != null; }

    public void set(Block b, int charges) {
        Map<String, Integer> m = read(b.getChunk());
        m.put(pos(b), Math.max(0, charges));
        write(b.getChunk(), m);
    }

    public void remove(Block b) {
        Map<String, Integer> m = read(b.getChunk());
        if (m.remove(pos(b)) != null) write(b.getChunk(), m);
    }
}
