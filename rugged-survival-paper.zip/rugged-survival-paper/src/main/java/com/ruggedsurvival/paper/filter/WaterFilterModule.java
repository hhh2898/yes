package com.ruggedsurvival.paper.filter;

import com.ruggedsurvival.paper.Hud;
import com.ruggedsurvival.paper.Items;
import com.ruggedsurvival.paper.RuggedSurvivalPlugin;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.CauldronLevelChangeEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.Map;

/**
 * The Water Filter is a cauldron placed from the custom "Water Filter" item.
 *  - Right-click it with Filter Media: loads filter-media-yield bottles (only when empty).
 *  - Right-click it with a plain Water Bottle: swaps it for Filtered Water and uses one bottle.
 * It is protected from rain filling, buckets, pistons and explosions so it stays a filter.
 */
public final class WaterFilterModule implements Listener {
    private final RuggedSurvivalPlugin plugin;
    private final FilterStore store;

    private WaterFilterModule(RuggedSurvivalPlugin plugin) {
        this.plugin = plugin;
        this.store = new FilterStore(plugin);
    }

    public static void register(RuggedSurvivalPlugin plugin) {
        Bukkit.getPluginManager().registerEvents(new WaterFilterModule(plugin), plugin);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (Items.is(e.getItemInHand(), Items.WATER_FILTER)) store.set(e.getBlockPlaced(), 0);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        if (!store.isFilter(b)) return;
        e.setDropItems(false); // drop our own item instead of a plain cauldron
        store.remove(b);
        if (e.getPlayer().getGameMode() != GameMode.CREATIVE) {
            b.getWorld().dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5), Items.create(Items.WATER_FILTER, 1));
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block b = e.getClickedBlock();
        if (b == null || b.getType() != Material.CAULDRON) return;
        Integer charges = store.get(b);
        if (charges == null) return; // an ordinary cauldron

        ItemStack held = e.getItem();
        if (held == null) return;
        Player p = e.getPlayer();
        Material m = held.getType();

        if (Items.is(held, Items.FILTER_MEDIA)) {
            e.setCancelled(true);
            if (charges > 0) { Hud.message(p, "The filter still has " + charges + " bottles left."); return; }
            int yield = plugin.cfg().filterMediaYield;
            store.set(b, yield);
            consumeOne(p, e.getHand(), held);
            Hud.message(p, "Filter media loaded (" + yield + " bottles).", NamedTextColor.GREEN);
        } else if (Items.isUntreatedWaterBottle(held)) {
            e.setCancelled(true);
            if (charges <= 0) { Hud.message(p, "The filter needs fresh filter media.", NamedTextColor.RED); return; }
            store.set(b, charges - 1);
            consumeOne(p, e.getHand(), held);
            Map<Integer, ItemStack> left = p.getInventory().addItem(Items.create(Items.FILTERED_WATER, 1));
            for (ItemStack rest : left.values()) p.getWorld().dropItemNaturally(p.getLocation(), rest);
            Hud.message(p, charges - 1 == 0 ? "That was the last of the filter media." : (charges - 1) + " bottles left.",
                    NamedTextColor.GREEN);
        } else if (m == Material.WATER_BUCKET || m == Material.LAVA_BUCKET || m == Material.POWDER_SNOW_BUCKET
                || m == Material.POTION || m == Material.GLASS_BOTTLE) {
            e.setCancelled(true); // do not let the filter be filled or emptied like a normal cauldron
        }
    }

    private void consumeOne(Player p, EquipmentSlot hand, ItemStack held) {
        if (p.getGameMode() == GameMode.CREATIVE) return;
        held.setAmount(held.getAmount() - 1);
        ItemStack left = held.getAmount() <= 0 ? null : held;
        if (hand == EquipmentSlot.OFF_HAND) p.getInventory().setItemInOffHand(left);
        else p.getInventory().setItemInMainHand(left);
    }

    @EventHandler(ignoreCancelled = true)
    public void onRain(CauldronLevelChangeEvent e) {
        if (store.isFilter(e.getBlock())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent e) { e.blockList().removeIf(store::isFilter); }

    @EventHandler(ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) { e.blockList().removeIf(store::isFilter); }

    @EventHandler(ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        if (e.getBlocks().stream().anyMatch(store::isFilter)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        if (e.getBlocks().stream().anyMatch(store::isFilter)) e.setCancelled(true);
    }
}
