# Rugged Survival (Paper plugin)

Server-side Paper plugin: thirst + water filter, tool-gated logging, aging health (4 -> 15 hearts),
age-gated armor, longer days and bleeding. Players use a normal vanilla client.

## Install
Put `RuggedSurvival-<version>.jar` in the server's `plugins/` folder and restart.
On first start it writes `plugins/RuggedSurvival/config.yml`.
On join you should see a gold chat line: "[Rugged Survival] plugin is active."

## Build the jar (GitHub, no installs)
1. Make a repo on github.com. Upload `rugged-survival-paper.zip` itself (do NOT extract it) via Add file -> Upload files.
2. Add the workflow: Add file -> Create new file, name it `.github/workflows/build.yml`, paste the contents of `build.yml`, commit.
3. Actions tab -> "Build plugin" -> when green, open the run and download the `rugged-survival-plugin` artifact.
4. Red X: open the failed step (or download `build-log`) and send the red text to Claude.

## Settings
`gradle.properties`: `minecraft_version` must match your Paper server. `plugin_version` must equal `version` in `src/main/resources/plugin.yml`.

## How it plays (vanilla client, no mods)
- **Thirst** shows in the action bar. A plain Water Bottle restores a little but gives Unsafe Water (faster drain, brief nausea).
  The **Water Filter** (6 cobblestone, 2 sand, 1 charcoal; placed like a cauldron) turns bottles into **Filtered Water**.
  Load it with **Filter Media** (charcoal + sand + gravel -> 2). Right-click the filter with a Water Bottle.
- **Logs** need a tool: punching one with bare hands hurts. Pick up **Loose Rocks** (flint named "Loose Rock", lying in newly
  generated areas, also sometimes dropped by dirt/sand/gravel) and craft a **Crude Handaxe** (3 rocks + stick, 2x2).
- **Age/health:** start at 4 hearts, +1 heart per 10 in-game days (to 15, age keeps rising). Armor tiers unlock at ages 1/7/11/18
  (shown in the item's lore). Death resets age and hearts.
- **Bleeding:** big hits can make you bleed (action bar shows BLEEDING); a **Bandage** (paper + string, or wool + string) stops it.
- **Longer days:** 30-minute days by default (config `longer-days.day-length-minutes`, 20-60).

## Admin commands (op / permission `rugged.admin`)
`/rugged status [player]`, `/rugged setage <player> <n>`, `/rugged setthirst <player> <n>`,
`/rugged give <item> [player]` (items: loose_rock, water_filter, filter_media, filtered_water, bandage, crude_handaxe), `/rugged reload`.

## If it loads but something does not work
Check the server log for lines starting `[Rugged Survival]`: each part logs `module OK` or `module FAILED` with the reason.
